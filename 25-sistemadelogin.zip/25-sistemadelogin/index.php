<?php
// Conexão
require_once 'db_connect.php';

// Header
include_once './includes/header.php';
// Sessão
session_start();

// Botão enviar
if (isset($_POST['btn-entrar'])) :
	$erros = array();
	$login = mysqli_escape_string($connect, $_POST['login']);
	$senha = mysqli_escape_string($connect, $_POST['senha']);


	if (empty($login) or empty($senha)) :
		$erros[] = "<li> O campo login/senha precisa ser preenchido </li>";
	else :
		// 105 OR 1=1 
		// 1; DROP TABLE teste

		$sql = "SELECT login FROM usuarios WHERE login = '$login'";
		$resultado = mysqli_query($connect, $sql);

		if (mysqli_num_rows($resultado) > 0) :
			$senha = md5($senha);

			$sql = "SELECT * FROM usuarios WHERE login = '$login' AND senha = '$senha'";



			$resultado = mysqli_query($connect, $sql);

			if (mysqli_num_rows($resultado) == 1) :
				$dados = mysqli_fetch_array($resultado);
				mysqli_close($connect);
				$_SESSION['logado'] = true;
				$_SESSION['id_usuario'] = $dados['id'];

				$_SESSION['admin'] = $dados['id'];


				header('Location: ./28-crud/index.php');
			else :
				$erros[] = "<li> Usuário e senha não conferem </li>";
			endif;

		else :
			$erros[] = "<li> Usuário inexistente </li>";
		endif;

	endif;

endif;
?>

<link rel="stylesheet" type="text/css" href="./style.css">
<nav class="nav-extended">
	<div class="nav-wrapper blue darken-3">
		<a class="brand-logo center">ControlVeiculos</a>



	</div>

</nav>


<div class="row">
	<div class="col s12 m6 offset-m3">
		<div class="card">
			<div class="card-action   light-blue accent-4 white-text">
				<h1  class="center"> LOGIN </h1>
			</div>
			<div class="card-content">
				<div class="form-field">
					<?php
					if (!empty($erros)) :
						foreach ($erros as $erro) :
							echo "<div class='btn '>$erro</div>";
						endforeach;
					endif;
					?>

					<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
						<div class="form-field">
							Username: <input type="text" name="login" placeholder="Nome do usuário" value="<?php echo isset($_COOKIE['login']) ? $_COOKIE['login'] : '' ?>"><br>
						</div><br>
						<div class="form-field">
							Senha: <input type="password" name="senha" placeholder="***************************" value="<?php echo isset($_COOKIE['senha']) ? $_COOKIE['senha'] : '' ?>"><br>
						</div><br>
						<button type="submit" name="btn-entrar" class="btn-large waves-effect waves-darke grey darken-1" style="width:100%;"> Entrar </button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>



<footer class="page-footer blue darken-3" style="position:absolute; bottom:0px; width:100%;">
	<div class="container">
		<div class="row">
			<div class="col s12 16 ">
				<h5>Bem vindo!</h5>
				
			</div>
		</div>
	</div>
	<div class="footer-copyright blue darker-4">
		<div class="container center-align">
			&copy; Contato (99) 99999-9999 - controlveiculos@gmail.com - © 2019 Copyright
		</div>
	</div>
</footer>

<?php


// Footer
include_once '28-crud/includes/footer.php';
?>