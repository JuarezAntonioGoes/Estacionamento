<?php
session_start();
// Conexão
require_once './28-crud/php_action/db_connect.php';
// Clear
function clear($input) {
	global $connect;
	// sql
	$var = mysqli_escape_string($connect, $input);
	// xss
	$var = htmlspecialchars($var);
	return $var;
}

if(isset($_POST['btn-cadastrar'])){
    $nome=clear($_POST['nome']);
    $nick=clear($_POST['nickname']);
    $senha=md5($_POST['senha']);
    if(isset($_POST['admin'])){
        $admin=1;
    }else{
        $admin=0;
    }

    $login = clear($_POST['nickname']);
	$sql = "SELECT login FROM usuarios WHERE login = '$login'";
	$resultado = mysqli_query($connect, $sql);
	if (mysqli_num_rows($resultado) == 1) {
		?><script>
			M.toast({
				html: 'Nickname já existe'
			});
			document.formu.nome.focus();
			</script><?php
			echo "Nickname já existe";
                        }
                        
                        
    $sql = "INSERT INTO usuarios (admin, nome, login, senha) VALUES ('$admin', '$nome', '$nick', '$senha')";
    if(mysqli_query($connect, $sql)):
		$_SESSION['mensagem'] = "Cadastrado com sucesso!";
		header('Location: ./28-crud/index.php');
	else:
		$_SESSION['mensagem'] = "Erro ao cadastrar";
		header('Location: ./28-crud/index.php');
		
	endif;
	unset($_SESSION['mensagem']);

}
?>
