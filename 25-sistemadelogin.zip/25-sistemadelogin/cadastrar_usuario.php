<?php
// Conexão
require_once './db_connect.php';

// Header
include_once '28-crud/includes/header.php';
// Sessão
include_once '28-crud/includes/verificacao_login.php';


////////

$id_adm = mysqli_escape_string($connect, $_SESSION['id_usuario']);

$res_adm = "SELECT * FROM usuarios WHERE id = '$id_adm'";
$resultado = mysqli_query($connect, $res_adm);
$dadoss = mysqli_fetch_array($resultado);

if ($dadoss['admin'] == 0) :
	echo header('Location: http://localhost/25-sistemadelogin/28-crud/index.php');
endif;

///////////
$nick = 0;

function clear($input)
{
	global $connect;
	// sql
	$var = mysqli_escape_string($connect, $input);
	// xss
	$var = htmlspecialchars($var);
	return $var;
}

?>
<script type="text/javascript" src="./cadastro.js"></script>

<link rel="stylesheet" type="text/css" href="./style.css">
<ul class="sidenav" id="mobile-demo">
<li><a href="./28-crud/index.php">Inicio</a></li>
<li><?php if ($dadoss['admin'] == 1) {
					echo "<a class='dropdown-trigger ' href='#' data-target='dropdown1'>Gerenciar Usuários</a>";
				}
				?></li>
	

	<li><a href="./logout.php">Sair</a></li>
</ul>
<nav style="width:100%;">
	<div class="nav-wrapper blue darken-3" >
		<ul id='dropdown1' class='dropdown-content'>
			<li><a href="./cadastrar_usuario.php">Cadastrar</a></li>
			<li><a href="./28-crud/alterar_usuario.php">Editar/Excluír</a></li>
			<li><a href="./logout.php" class="">Sair</a></li>

		</ul>
		<a href="#!" class="brand-logo center">ControlVeiculos</a>
		<a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
		<ul class="right hide-on-med-and-down">
		<li><a href="./28-crud/index.php">Inicio</a></li>
			<li><?php if ($dadoss['admin'] == 1) {
					echo "<a href='./cadastrar_usuario.php'>Cadastrar novo usuario</a>";
				}
				?></li>
			<li><?php if ($dadoss['admin'] == 1) {
					echo "<a href='./28-crud/alterar_usuario.php'>Editar/Excluir usuario</a>";
				}
				?></li>
			<li><a href="./logout.php" class="right">Sair</a></li>
		</ul>
	</div>
</nav>


<div class="row">
	<div class="col s12 m8 push-m2">
		<h1> Cadastro de usuários </h1>
		<?php
		/*$verifica_usuarios = mysqli_query($connect, "select * from usuarios limit 1");
	if(mysqli_num_rows($verifica_usuarios)>0){
*/


		/*$nome = $_POST['nome'];

			$campos= array();
			if($nome!=""){
				array_push($campos, "ola josias");
			}

			if(count($campos)>0){
				echo "<div class='erros'></div>";
				for($i=0; $i < count($campos); $i++){
					echo"<li>".$campos[$i]."</li>";
				}

			}else{
				echo "<div class='correto'>ola</div>";
			}

*/
		if (isset($_POST['btn-voltar'])) {
			header('Location: http://localhost/25-sistemadelogin/28-crud/index.php');
		}



		if (isset($_POST['btn-cadastrar'])) {
			$nome = clear($_POST['nome']);
			$nickn = clear($_POST['nickname']);
			$senha = md5($_POST['senha']);
			if (isset($_POST['admin'])) {
				$admin = 1;
			} else {
				$admin = 0;
			}
			date_default_timezone_set('America/Sao_Paulo');
			$data_hora = date('d/m/Y H:i:s');

			$nick = 0;

			$login = $_POST['nickname'];

			$sql = "SELECT login FROM usuarios WHERE login = '$login'";

			$resultado = mysqli_query($connect, $sql);
			if (mysqli_num_rows($resultado) == 1) {

				//echo "Nickname já existe";
				$nick = 1;
			} else {



				$sql = "INSERT INTO usuarios (admin, nome, login, senha, data_hora) VALUES ('$admin', '$nome', '$nickn', '$senha','$data_hora')";
				if (mysqli_query($connect, $sql)) :
					$_SESSION['mensagem'] = "Cadastrado com sucesso!";
					header('Location: ./28-crud/alterar_usuario.php');
				else :
					$_SESSION['mensagem'] = "Erro ao cadastrar";
					header('Location: ./28-crud/alterar_usuario.php');

				endif;
				unset($_SESSION['mensagem']);
			}
		}

		?>


		<form action="" name="formu" method="POST" onSubmit="return valid();">
			Nome<input type="text" name="nome" placeholder="Nome do usuário" value=""><br>

			Nickname: <input type="text" id="nick" name="nickname" placeholder="Ex: cesar.augusto" value=""><br>
			<?php if ($nick == 1) {
				echo "<div class='btn red'>Nickname já existe</div><br>";
			} else {
				echo "";
			}
			?>

			Senha: <input type="password" name="senha" placeholder="A senha deve conter de 5 a 8 caracteres" value=""><br>
			Confirmar senha: <input type="password" name="conf_senha" placeholder="***************************" value=""><br>
			<p>
				<label>
					<input type="checkbox" name="admin" />
					<span>Atuar como Administrador</span>
				</label>
			</p>

			<button type="submit" name="btn-cadastrar" class="btn blue"> Cadastrar </button>
		</form>

		<form action="" method="POST">
			<br>
			<button type="submit" name="btn-voltar" class="btn ">Voltar para tela inicial</button>
			<br><br>
		</form>


	</div>
</div>
<footer class="page-footer blue darken-3" style="position:absolute; bottom:0px; width:100%;">

	<div class="container center-align">
		&copy; Contato (99) 99999-9999 - controlveiculos@gmail.com - © 2019 Copyright
	</div>

</footer>

<?php


// Footer
include_once '28-crud/includes/footer.php';
?>