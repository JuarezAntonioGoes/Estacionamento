function valid() {
    if (document.formu.nome.value == "") {
        M.toast({ html: 'Por favor, preencha o campo "Nome"' });
        document.formu.nome.focus();
        return false;
    }

    if (document.formu.nickname.value == "") {
        M.toast({ html: 'Por favor, preencha o campo "Nickname"' });
        document.formu.nickname.focus();
        return false;
    }
    if (document.formu.nickname.value == "admin") {
        M.toast({ html: 'O Nickname não pode ser admin' });
        document.formu.nickname.focus();
        return false;
    }

    if (document.formu.senha.value == "") {
        M.toast({ html: 'Por favor, preencha o campo "Senha"' });
        document.formu.senha.focus();
        return false;
    }
    if (document.formu.senha.value.length <5 ) {
        M.toast({ html: 'A senha deve ter dentre 5 a 8 caracteres' });
        document.formu.senha.focus();
        return false;
    }

    if (document.formu.senha.value.length >8) {
        M.toast({ html: 'A senha deve ter dentre 5 a 8 caracteres' });
        document.formu.senha.focus();
        return false;
    }

    if (document.formu.conf_senha.value == "") {
        M.toast({ html: 'Por favor, preencha o campo "Confirmar senha"' });
        document.formu.conf_senha.focus();
        return false;
    }

    if (document.formu.conf_senha.value != document.formu.senha.value) {
        M.toast({ html: 'As senhas não se coincidem' });
        document.formu.conf_senha.focus();
        return false;
    }

}

