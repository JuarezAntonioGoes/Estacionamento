 <!DOCTYPE html>
  <html lang="pt-br">
    <head>
      <meta charset="utf-8">
      <title> Sistema de cadastro de clientes</title>

      <!--Import Google Icon Font-->
      <link href="./includes/icon.css" rel="stylesheet" >
      <!--Import materialize.css-->
      
       <link rel="stylesheet" href="./includes/materialize.min.css">

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <script src="../jquery-3.4.1.min.js"></script>
      <script src="../javascript.js"></script>
    </head>

    <body>

    