function valid() {

    if (document.form.placa.value == "") {
        M.toast({ html: 'Por favor, preencha o campo "Placa"' });
        document.form.placa.focus();
        return false;
    }
    if (document.form.placa.value.length < 8) {
        M.toast({ html: ' Placa inválida' });
        document.form.placa.focus();
        return false;
    }


    if (document.form.entrada.value == "") {
        M.toast({ html: 'Por favor, preencha o campo "Hora de entrada"' });
        document.form.entrada.focus();
        return false;
    }

    if (document.form.entrada.value.length < 5) {
        M.toast({ html: 'Hora de entrada inválida' });
        document.form.entrada.focus();
        return false;
    }

    if (document.form.data_entrada.value == "") {
        M.toast({ html: 'Por favor, preencha o campo "Data de entrada"' });
        document.form.data_entrada.focus();
        return false;
    }

    if (document.form.data_entrada.value.length < 10) {
        M.toast({ html: "Data de entrada inválida" });
        document.form.data_entrada.focus();
        return false;
    }




    if (document.form.saida.value != "" && document.form.saida.value.length < 5) {
        M.toast({ html: 'Hora de saida invalida' });
        document.form.placa.focus();
        return false;
    }


    if (document.form.data_saida.value != "" && document.form.saida.value == "") {
        M.toast({ html: 'Preencha o campo "saída"' });
        document.form.saida.focus();
        return false;
    }

    if (document.form.data_saida.value != "") {
        if (document.form.data_saida.value.length < 10) {
            M.toast({ html: "Data de saída inválida" });
            document.form.data_saida.focus();
            return false;
        }
        var abc=document.form.data_saida.value;
        var bbc=document.form.data_entrada.value;
        if (abc < bbc) {
            M.toast({ html: "Data de saída menor que data de entrada" });
            document.form.data_saida.focus();
            return false;
        }
    
    }

    if (document.form.data_saida.value != "" && (document.form.data_saida.value < document.formu.data_entrada.value)) {
        M.toast({ html: "Data de saída menor que data de entrada" });
        document.form.data_saida.focus();
        return false;
    }

    if (document.form.saida.value != "" && document.form.data_saida.value == "") {
        M.toast({ html: 'Preencha o campo "Data de saída"' });
        document.form.data_saida.focus();
        return false;
    }

    

}
