<?php 
//Incluir a conexão com banco de dados
include_once 'php_action/db_connect.php';

include_once 'includes/header.php';
// Select
include_once 'includes/verificacao_login.php';



$id_adm = mysqli_escape_string($connect, $_SESSION['id_usuario']);

$res_adm = "SELECT * FROM usuarios WHERE id = '$id_adm'";
$resultado = mysqli_query($connect, $res_adm);
$dadoss = mysqli_fetch_array($resultado);

if($dadoss['admin']==0):
	echo header('Location: http://localhost/25-sistemadelogin/28-crud/index.php');
endif;

$usuarios = filter_input(INPUT_POST, 'palavra', FILTER_SANITIZE_STRING);

//Pesquisar no banco de dados nome do usuario referente a palavra digitada
$result_user = "SELECT * FROM usuarios  WHERE login LIKE '%$usuarios%' LIMIT 1";
$resultado_user = mysqli_query($connect, $result_user);

if (($resultado_user) and ($resultado_user->num_rows != 0)) {
	
	while ($row_user = mysqli_fetch_assoc($resultado_user)) {
		
		?>

		<table class="striped">
			<thead>
				<tr>
					<th>Nickname:</th>
					<th>Nome:</th>
					<th>Admin:</th>
					
				</tr>
			</thead>

			<tbody>
				<tr>

					<td><?php echo $row_user['login']; ?></td>
					<td><?php echo $row_user['nome']; ?></td>
					<td><?php if ($row_user['admin'] == 1) {
						 echo "Sim";
					 }else{
						echo "Não";
					 } ?></td>



					
					
<?php if ($dadoss['login'] == $row_user['login']) { ?>
								<td><a href="" class="btn-floating orange" disabled><i class="material-icons">edit</i></a></td>
							<?php } else { ?>

								<td><a href="editar_usu.php?id=<?php echo $row_user['id']; ?>" class="btn-floating orange"><i class="material-icons">edit</i></a></td>

							<?php } ?>

							<?php if ($dadoss['login'] == $row_user['login']) { ?>
								<td><a href="" class="btn-floating red modal-trigger" disabled><i class="material-icons">delete</i></a></td>
							<?php } else { ?>

								<td><a href="#modal<?php echo $row_user['id']; ?>" class="btn-floating red modal-trigger"><i class="material-icons">delete</i></a></td>
							<?php } ?>


		<?php
			}
		} else {
			echo "Nenhum usuário encontrado ...";
			
		}
