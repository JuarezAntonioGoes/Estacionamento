<?php
// Conexão
include_once 'php_action/db_connect.php';
// Header
include_once 'includes/header.php';
// Select
include_once 'includes/verificacao_login.php';



$id_adm = mysqli_escape_string($connect, $_SESSION['id_usuario']);

$res_adm = "SELECT * FROM usuarios WHERE id = '$id_adm'";
$resultado = mysqli_query($connect, $res_adm);
$dadoss = mysqli_fetch_array($resultado);

if ($dadoss['admin'] == 0) :
    echo header('Location: http://localhost/25-sistemadelogin/28-crud/index.php');
endif;



?>

<script type="text/javascript" src="../cadastroo.js"></script>
<script type="text/javascript" src="../28-crud/valida.js"></script>
<script type="text/javascript" src="../28-crud/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="../28-crud/jquery-migrate-3.0.0.js"></script>
<script type="text/javascript" src="../28-crud/jQuery-Mask-Plugin-master/src/jquery.mask.js"></script>


<script type="text/javascript">
    // Material Select Initialization
    $(document).ready(function() {






        $("#data_entrada").mask("00/00/0000")
        $("#data_saida").mask("00/00/0000")
        $("#entrada").mask("00:00")
        $("#saida").mask("00:00")
        $("#km").mask("000.000.000.000", {
            reverse: true
        })
        var options = {
            translation: {
                'A': {
                    pattern: /[A-Z]/
                },
                'a': {
                    pattern: /[a-zA-Z]/
                },
            }
        }
        $("#placa").mask("aaa-0000", options)
    });
</script>

<ul class="sidenav" id="mobile-demo">
<li><a href="./index.php">Inicio</a></li>
<li><?php if ($dadoss['admin'] == 1) {
					echo "<a class='dropdown-trigger ' href='#' data-target='dropdown1'>Gerenciar Usuários</a>";
				}
				?></li>
	

	<li><a href="../logout.php">Sair</a></li>
</ul>
<nav style="width:100%;">
	<div class="nav-wrapper blue darken-3" >
		<ul id='dropdown1' class='dropdown-content'>
            
			<li><a href="../cadastrar_usuario.php">Cadastrar</a></li>
			<li><a href="./alterar_usuario.php">Editar/Excluír</a></li>
			<li><a href="./logout.php" class="">Sair</a></li>

		</ul>
		<a href="#!" class="brand-logo center">ControlVeiculos</a>
		<a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
		<ul class="right hide-on-med-and-down">
        <li><a href="./index.php">Inicio</a></li>

			<li><?php if ($dadoss['admin'] == 1) {
					echo "<a href='../cadastrar_usuario.php'>Cadastrar novo usuario</a>";
				}
				?></li>
			<li><?php if ($dadoss['admin'] == 1) {
					echo "<a href='./alterar_usuario.php'>Editar/Excluir usuario</a>";
				}
				?></li>
			<li><a href="../logout.php" class="right">Sair</a></li>
		</ul>
	</div>
</nav>

<?php
if (isset($_GET['id'])) :
    $id = mysqli_escape_string($connect, $_GET['id']);

    $sql = "SELECT * FROM usuarios WHERE id = '$id'";
    $resultado = mysqli_query($connect, $sql);
    $dados = mysqli_fetch_array($resultado);
    if ($dadoss['login'] == $dados['login']) {
        echo header('Location: http://localhost/25-sistemadelogin/28-crud/alterar_usuario');
    }
endif;







?>

<div class="row">
    <div class="col s12 m6 push-m3">
        <h3 class="light"> Editar Cliente </h3>
        <form action="php_action/update-usu.php" method="POST" name="formu" onSubmit="return valida();">
            <input type="hidden" name="id" value="<?php echo $dados['id']; ?>">




            <div class="input-field col s12">
                <input type="text" name="nickname" id="nick" value="<?php echo $dados['login']; ?> ">
                <label for="placa">Nickname</label>
            </div>





            <div class="input-field col s12">
                <input type="text" name="nome" id="nome" value="<?php echo $dados['nome']; ?>">
                <label for="entrada">nome</label>
            </div>


            <div class="input-field col s12">
                <fieldset>
                    <legend>Gerar nova senha (OPCIONAL): </legend>

                    Nova senha: <input type="password" name="senha" placeholder="A senha deve conter de 5 a 8 caracteres" value=""><br>
                    Confirmar senha: <input type="password" name="conf_senha" placeholder="***************************" value=""><br>
                </fieldset>
            </div>
            <?php if ($dados['admin'] == 1) { ?>
                <p>
                    <label>
                        <input type="checkbox" name="admin" checked />
                        <span>Atuar como Administrador</span>
                    </label>
                </p>

            <?php  } else { ?>
                <p>
                    <label>
                        <input type="checkbox" name="admin" />
                        <span>Atuar como Administrador</span>
                    </label>
                </p>
            <?php   } ?>








            <button type="submit" name="btn-editar-usu" class="btn"> Atualizar</button>






            <a href="alterar_usuario.php" class="btn green"> Lista de usuários </a>
        </form>

    </div>
</div>



<footer class="page-footer blue darken-3" style="position:absolute; bottom:0px; width:100%;">

	<div class="container center-align">
		&copy; Contato (99) 99999-9999 - controlveiculos@gmail.com - © 2019 Copyright
	</div>

</footer>
<?php
// Footer
include_once 'includes/footer.php';
?>