function valida() {
if (document.formu.saida.value == "") {
    M.toast({ html: 'Por favor, preencha o campo "de saída"' });
    document.formu.saida.focus();
    return false;
}

if (document.formu.saida.value.length < 5) {
    M.toast({ html: "Hora de saída inválida" });
    document.formu.saida.focus();
    return false;
}

if (document.formu.data_saida.value == "") {
    M.toast({ html: 'Por favor, preencha o campo "Data de entrada"' });
    document.formu.data_entrada.focus();
    return false;
}

if (document.formu.data_saida.value.length < 10) {
    M.toast({ html: "Data de saída inválida" });
    document.formu.data_saida.focus();
    return false;
}

if(document.formu.data_saida.value<document.formu.data_entrada.value){
    M.toast({ html: "Data de saída menor que data de entrada" });
    document.formu.data_saida.focus();
    return false;
}
}