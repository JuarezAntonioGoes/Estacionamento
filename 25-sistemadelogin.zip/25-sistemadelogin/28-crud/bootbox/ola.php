<?php
include '../php_action/db_connect.php'; 
include_once '../verificacao_login.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Redirecionamento</title>

    <!-- CSS dependencies -->
    <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
</head>

<body>
    <?php
    $idd = $_GET['id'];

    ?>
    <script>
        var ola_id = <?php "../editar.php?id=219" . $idd ?>;
    </script>

    <!-- JS dependencies -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Bootstrap 4 dependency -->
    <script src="popper.min.js"></script>
    <script src="bootstrap.min.js"></script>

    <!-- bootbox code -->
    <script src="bootbox.min.js"></script>
    <script src="bootbox.locales.min.js"></script>
    <script>
        var newUrl = window.location.href;
        var url = [];
        var j = 0;
        var a = 0;
        var urll = [];
        var kkk = "";
        for (var i = 62; i < newUrl.length; i++) {

            url[j] = newUrl[i];
            kkk = kkk + url[j]
            j++;
        }



        var senha = 1234;
        var Validacao = bootbox.prompt({
            title: "Digite a senha:",
            inputType: 'password',
            callback: function(result) {
                if (result == senha) {

                    window.location.href = "../editar.php?id=" + kkk;
                } else {
                    bootbox.prompt({
                        title: "Senha incorreta digite novamente:",
                        inputType: 'password',
                        callback: function(resultado) {
                            if (resultado == senha) {
                                window.location.href = "../editar.php?id=" + kkk;
                            } else {
                                bootbox.prompt({
                                    title: "(1) TENTATIVA RESTANTE",
                                    inputType: 'password',
                                    callback: function(resultadoo) {
                                        if (resultadoo == senha) {
                                            window.location.href = "../editar.php?id=" + kkk;
                                        } else {
                                            bootbox.alert("Você será redirecionado para a página principal");
                                            window.location.href = "../index.php";
                                        }
                                    }
                                });
                            }
                        }
                    });
                }
            }
        });
    </script>
</body>

</html>