<?php
include 'php_action/db_connect.php';



require_once("/wamp64/www/25-sistemadelogin/28-crud/phpqrcode/qrlib.php");
QRCode::png("http://localhost/25-sistemadelogin/28-crud/gerarpdf.php?id=".$_GET['id']);
?>