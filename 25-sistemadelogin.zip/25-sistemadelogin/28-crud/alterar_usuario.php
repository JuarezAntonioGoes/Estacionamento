<?php

// Conexão
require_once 'php_action/db_connect.php';

// Header
include_once 'includes/header.php';




include_once 'includes/verificacao_login.php';
include_once 'includes/message.php';


$id_adm = mysqli_escape_string($connect, $_SESSION['id_usuario']);

$res_adm = "SELECT * FROM usuarios WHERE id = '$id_adm'";
$resultado = mysqli_query($connect, $res_adm);
$dadoss = mysqli_fetch_array($resultado);

if($dadoss['admin']==0):
	echo header('Location: http://localhost/25-sistemadelogin/28-crud/index.php');
endif;

?>




<ul class="sidenav" id="mobile-demo">
<li><a href="./index.php">Inicio</a></li>
<li><?php if ($dadoss['admin'] == 1) {
					echo "<li><a href='../cadastrar_usuario.php'>Cadastrar</a></li>
					<li><a href='./alterar_usuario.php'>Editar/Excluír</a></li>";
				}
				?></li>
	

	<li><a href="../logout.php">Sair</a></li>
</ul>
<nav style="width:100%;">
	<div class="nav-wrapper blue darken-3" >
		<ul id='dropdown1' class='dropdown-content'>
			<li><a href="./28-crud/index.php">Inicio</a></li>
			<li><a href="../cadastrar_usuario.php">Cadastrar</a></li>
			<li><a href="./alterar_usuario.php">Editar/Excluír</a></li>
			<li><a href="./logout.php" class="">Sair</a></li>

		</ul>
		<a href="#!" class="brand-logo center">ControlVeiculos</a>
		<a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
		<ul class="right hide-on-med-and-down">
		<li><a href="./index.php">Inicio</a></li>
			<li><?php if ($dadoss['admin'] == 1) {
					echo "<a href='../cadastrar_usuario.php'>Cadastrar novo usuario</a>";
				}
				?></li>
			<li><?php if ($dadoss['admin'] == 1) {
					echo "<a href='./alterar_usuario.php'>Editar/Excluir usuario</a>";
				}
				?></li>
			<li><a href="../logout.php" class="right">Sair</a></li>
		</ul>
	</div>
</nav>

<ul class="sidenav" id="mobile-demo">
<li><?php if ($dadoss['admin'] == 1) {
					echo "<a class='dropdown-trigger ' href='#' data-target='dropdown1'>Gerenciar Usuários</a>";
				}
				?></li>
	

	<li><a href="../logout.php">Sair</a></li>
</ul>


<br>
<div class="row">
    <div class="col s12 m8 push-m2">

        <form action="" method="POST" id="form-pesquisa"></form>
        <div class="input-field col s12">
         
            <input type="text" id="pesquisaa" class="autocomplete" name="pesquisar" placeholder="Digite o nickname do usuário">
            <i class="material-icons prefix">search</i>
        </div>
        </form>

        <ul class="resultado">

        </ul>
		<table class="striped">
		<thead>
				<tr>
					<th>Nickname:</th>
					<th>Nome:</th>
					<th>Admin:</th>
					
				</tr>
			</thead>

			<tbody>
				<?php
				//Receber o número da pagina
				$pagina_atual = filter_input(INPUT_GET, 'pagina', FILTER_SANITIZE_NUMBER_INT);
				$pagina = (!empty($pagina_atual)) ? $pagina_atual : 1;

				//Setar a quantidade de itens por pagina
				$qnt_result_pg = 5;

				//calcular inicio da visualização
				$inicio = ($qnt_result_pg * $pagina) - $qnt_result_pg;


				/////////////////////////ola
				$sql = "SELECT * FROM usuarios order by data_hora  DESC LIMIT $inicio, $qnt_result_pg";
				$resultado = mysqli_query($connect, $sql);

				if (mysqli_num_rows($resultado) > 0) :

					while ($dados = mysqli_fetch_array($resultado)) :
						?>
						<tr>
						<td><?php echo $dados['login']; ?></td>
					<td><?php echo $dados['nome']; ?></td>
					<td><?php if ($dados['admin'] == 1) {
						 echo "Sim";
					 }else{
						echo "Não";
					 } ?></td>

							
									

							<?php if ($dadoss['login'] == $dados['login']) { ?>
								<td><a href="" class="btn-floating orange" disabled><i class="material-icons">edit</i></a></td>
							<?php } else { ?>

								<td><a href="editar_usu.php?id=<?php echo $dados['id']; ?>" class="btn-floating orange"><i class="material-icons">edit</i></a></td>

							<?php } ?>

							<?php if ($dadoss['login'] == $dados['login']) { ?>
								<td><a href="" class="btn-floating red modal-trigger" disabled><i class="material-icons">delete</i></a></td>
							<?php } else { ?>

								<td><a href="#modal<?php echo $dados['id']; ?>" class="btn-floating red modal-trigger"><i class="material-icons">delete</i></a></td>
							<?php } ?>
							<!-- Modal Structure -->
							<?php if ($dadoss['login'] != $dados['login']) : ?>
								<div id="modal<?php echo $dados['id']; ?>" class="modal">
									<div class="modal-content">
										<h4>Opa!</h4>
										<p>Tem certeza que deseja excluir esse usuário?</p>
									</div>
									<div class="modal-footer">

										<form action="php_action/delete.php" method="POST">
											<input type="hidden" name="id" value="<?php echo $dados['id']; ?>">
											<button type="submit" name="btn-deletarr" class="btn red">Sim, quero deletar</button>

											<a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Cancelar</a>

										</form>

									</div>
								</div>
							<?php endif; ?>


						</tr>
					<?php
						endwhile;
					else : ?>

					<tr>
						<td>-</td>
						<td>-</td>
						<td>-</td>
						
					</tr>

				<?php
				endif;

				$result_pg = "SELECT COUNT(id) AS num_result FROM usuarios";
				$resultado_pg = mysqli_query($connect, $result_pg);
				$row_pg = mysqli_fetch_assoc($resultado_pg);
				//echo $row_pg['num_result'];
				//Quantidade de paginas
				$quantidade_pg = ceil($row_pg['num_result'] / $qnt_result_pg);

				//Limitar os links
				$max_links = 2;



				for ($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++) {
					if ($pag_ant >= 1) {
						echo "<a href='http://localhost/25-sistemadelogin/28-crud/alterar_usuario.php?pagina=$pag_ant' name='abacaxi' class='btn'>$pag_ant</a> ";
					}
				}

				echo "<div class='btn deep-orange ' name='abacaxi' disabled>$pagina</div> ";

				for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++) {
					if ($pag_dep <= $quantidade_pg) {
						echo "<a href='http://localhost/25-sistemadelogin/28-crud/alterar_usuario.php?pagina=$pag_dep' name='abacaxi' class='btn'>$pag_dep</a> ";
					}
				}
				//	echo $_SESSION['mensagem'];


				?>

			</tbody>
		</table>
		<br>

		
	</div>
</div>
<footer class="page-footer blue darken-3" style="position:absolute; bottom:0px; width:100%;">

	<div class="container center-align">
		&copy; Contato (99) 99999-9999 - controlveiculos@gmail.com - © 2019 Copyright
	</div>

</footer>
<?php


// Footer
include_once 'includes/footer.php';

?>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>

<script type="text/javascript" src="personalizadoo.js"></script>