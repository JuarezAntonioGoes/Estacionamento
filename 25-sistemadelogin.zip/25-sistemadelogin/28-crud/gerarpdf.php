<?php

use chillerlan\QRCode\QRCode;

include 'pdf//fpdf.php';

include 'php_action/db_connect.php';

include 'LIB/vendor//autoload.php';



$idd=$_GET['id'];

$url= 'http://localhost/25-sistemadelogin/28-crud/gerarpdf.php?id='.$idd;

if (isset($_GET['id'])) :
	$id = mysqli_escape_string($connect, $_GET['id']);

	$sql = "SELECT * FROM clientes WHERE id = '$id'";
	$resultado = mysqli_query($connect, $sql);
	$dados = mysqli_fetch_array($resultado);
endif;

$pdf = new FPDF();

$pdf=new FPDF('P','cm',array(16,13));
$pdf->AddPage();
$pdf->SetFont('Arial','B',10);
$pdf->Cell(0,0,utf8_decode('_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ '),0,0,"C");
$pdf->Ln(0.5);

$pdf->SetFont('Arial','B',13);
$pdf->Cell(0,0,utf8_decode('ControlVeiculos'),0,0,"C");
$pdf->Ln(0.5);

$pdf->SetFont('Arial','I',10);
$pdf->Cell(0,0,utf8_decode('Pouso Alegre - MG, FATIMA, AV. JOSE RICO 1666'),0,0,"L");
$pdf->Ln(1);
$pdf->Cell(0,0,utf8_decode('CNPJ: 00.000.000/0000-00'),0,0,"L");
$pdf->Ln(0.5);


$pdf->SetFont('Arial','B',10);
$pdf->Cell(0,0,utf8_decode('_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ '),0,0,"C");
$pdf->Ln(0.5);





$pdf->SetFont('Arial','I',9);
$pdf->Cell(0,0,"Placa:",0,0,"L");
$pdf->Cell(-2,0,"....................................................................",0,0,"R");
$pdf->Cell(0,0,utf8_decode($dados['placa']),0,0,"R");
$pdf->Ln(0.5);

$pdf->SetFont('Arial','I',9);
$pdf->Cell(0,0,utf8_decode("Data de entrada:"),0,0,"L");
$pdf->Cell(-2,0,"....................................................................",0,0,"R");
$pdf->Cell(0,0,utf8_decode($dados['data_entrada']),0,0,"R");
$pdf->Ln(0.5);

$pdf->SetFont('Arial','I',9);
$pdf->Cell(0,0,utf8_decode("Hora de entrada:"),0,0,"L");
$pdf->Cell(-2,0,"....................................................................",0,0,"R");
$pdf->Cell(0,0,utf8_decode($dados['entrada']).":00",0,0,"R");
$pdf->Ln(0.5);

$pdf->SetFont('Arial','I',9);
$pdf->Cell(0,0,utf8_decode("Data de saída:"),0,0,"L");
$pdf->Cell(-2,0,"....................................................................",0,0,"R");
$pdf->Cell(0,0,utf8_decode($dados['data_saida']),0,0,"R");
$pdf->Ln(0.5);

$pdf->SetFont('Arial','I',9);
$pdf->Cell(0,0,utf8_decode("Hora de saída:"),0,0,"L");
$pdf->Cell(-2,0,"....................................................................",0,0,"R");
$pdf->Cell(0,0,utf8_decode($dados['saida']).":00",0,0,"R");
$pdf->Ln(0.5);

$pdf->SetFont('Arial','I',9);
$pdf->Cell(0,0,"Tempo utilizado:",0,0,"L");
$pdf->Cell(-2,0,"....................................................................",0,0,"R");
$pdf->Cell(0,0,utf8_decode($dados['hora_total']).":00",0,0,"R");
$pdf->Ln(0.5);

$pdf->SetFont('Arial','B',9);
$pdf->Cell(0,0,utf8_decode("Preço Total:"),0,0,"L");
$pdf->Cell(-2,0,"....................................................................",0,0,"R");
$pdf->Cell(0,0,"R$".utf8_decode($dados['preco_total']),0,0,"R");

$pdf->Ln(0.5);

$pdf->SetFont('Arial','B',9);
$pdf->Cell(0,0,utf8_decode('_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ '),0,0,"C");
$pdf->Ln(0.8);

$pdf->SetFont('Arial','I',14);
$pdf->Cell(0,0,"VOLTE SEMPRE!!!",0,0,"C");
$pdf->Ln(0.5);

$pdf->Image("http://localhost/25-sistemadelogin/28-crud/QrCode.php?id=".$idd,5, 8.9, 3, 3, "png");


$pdf->SetFont('Arial','B',9);
$pdf->Cell(0,0,utf8_decode('_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ '),0,0,"C");
$pdf->Ln(0.5);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(0,4.65,utf8_decode('_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ '),0,20,"C");
$pdf->Ln(0.5);

$pdf->Output();


?>