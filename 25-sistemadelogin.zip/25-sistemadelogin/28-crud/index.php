<script type="text/javascript" src="../28-crud/jquery-3.4.1.min.js"></script>

<script>
	function ocultar_div() {
		$('#TipodeDocumento').on('change', function() {
			$('.div-sel').hide();
			var selecionado = $(this).val();
			$('.div-sel').each(function() {
				if ($(this).attr('id') == selecionado) {
					$(this).toggle();
				} else {
					$(this).hide();
				}
			});
		});
	}

	$(window).on('load', function() {
		ocultar_div();
		$('#TipodeDocumento').val('div1').trigger('change');
	});
</script>
<?php

// Conexão
require_once 'php_action/db_connect.php';

// Header
include_once 'includes/header.php';




include_once 'includes/verificacao_login.php';
include_once 'includes/message.php';

//$admin = "SELECT * FROM usuarios";
/*$res_adm = mysqli_query($connect, $admin);
if (mysqli_num_rows($res_adm) > 0) :
	while ($daaa = mysqli_fetch_array($res_adm)){
		echo $daaa['login'];
	}
endif;
echo "ola";
echo $_SESSION['id_usuario'];*/


$id_adm = mysqli_escape_string($connect, $_SESSION['id_usuario']);

$res_adm = "SELECT * FROM usuarios WHERE id = '$id_adm'";
$resultado = mysqli_query($connect, $res_adm);
$dadoss = mysqli_fetch_array($resultado);
//if ($dadoss['admin'] == 0) {
///	echo	$dadoss['admin'];
//}



?>




<ul class="sidenav" id="mobile-demo">
	<li><?php if ($dadoss['admin'] == 1) {
			echo "<a class='dropdown-trigger ' href='#' data-target='dropdown1'>Gerenciar Usuários</a>";
		}
		?></li>


	<li><a href="../logout.php">Sair</a></li>
</ul>






<nav style="width:100%;">
	<div class="nav-wrapper blue darken-3">
		<ul id='dropdown1' class='dropdown-content'>
			<li><a href="../cadastrar_usuario.php">Cadastrar</a></li>
			<li><a href="./alterar_usuario.php">Mais..</a></li>
			<li><a href="../logout.php" class="">Sair</a></li>

		</ul>
		<a href="#!" class="brand-logo center">ControlVeiculos</a>
		<a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
		<ul class="right hide-on-med-and-down">

			<li><?php if ($dadoss['admin'] == 1) {
					echo "<a href='../cadastrar_usuario.php'>Cadastrar novo usuario</a>";
				}
				?></li>
			<li><?php if ($dadoss['admin'] == 1) {
					echo "<a href='./alterar_usuario.php'>Editar/Excluir usuario</a>";
				}
				?></li>
			<li><a href="../logout.php" class="right">Sair</a></li>
		</ul>
	</div>
</nav>






<div class="col s12 m6 push-m3 ">
	<select class="col s8" name="TipodeDocumento" id="TipodeDocumento">

		<option value="div1" selected>HOME</option>
		<option value="div2">PESQUISAR VEÍCULO</option>
	</select>
</div>





<br>
<div class="row">
	<div class="col s12 ">
		<div class="div-sel" id="div2">
			<form action="" method="POST" id="form-pesquisa"></form>
			<div class="input-field col s12">
				<label for="">Search</label>
				<input type="text" id="pesquisa" class="autocomplete" name="pesquisar" placeholder="Digite o número da placa">
				<i class="material-icons prefix">search</i>
			</div>
			</form>

			<ul class="resultado">

			</ul>

		</div>


		<div class="div-sel" id="div1">
			<table class="striped">
				<thead>
					<tr>

						<th>Placa:</th>
						<th>Hora de entrada:</th>
						<th>Data de entrada:</th>
						<th>Hora de saída:</th>
						<th>Data de saída:</th>
						<th>Horas utilizadas:</th>
						<th>Valor a pagar:</th>
						<th>Saida:</th>
						<th>Recibo:</th>
					</tr>
				</thead>

				<tbody>
					<?php
					//Receber o número da pagina
					$pagina_atual = filter_input(INPUT_GET, 'pagina', FILTER_SANITIZE_NUMBER_INT);
					$pagina = (!empty($pagina_atual)) ? $pagina_atual : 1;

					//Setar a quantidade de itens por pagina
					$qnt_result_pg = 7;

					//calcular inicio da visualização
					$inicio = ($qnt_result_pg * $pagina) - $qnt_result_pg;


					/////////////////////////ola
					$sql = "SELECT * FROM clientes order by id DESC LIMIT $inicio, $qnt_result_pg";
					$resultado = mysqli_query($connect, $sql);

					if (mysqli_num_rows($resultado) > 0) :

						while ($dados = mysqli_fetch_array($resultado)) :
							?>
							<tr>
								<td><?php if ($dados['placa'] != NULL) {

												echo $dados['placa'];
											} else {
												echo "-";
											} ?></td>
								<td><?php if ($dados['entrada'] != NULL) {

												echo $dados['entrada'] . ":00";
											} else {
												echo "-";
											} ?></td>
								<td><?php if ($dados['data_entrada'] != NULL) {

												echo $dados['data_entrada'];
											} else {
												echo "-";
											} ?></td>
								<td><?php if ($dados['saida'] == NULL) {
												echo "-";
											} else {
												echo $dados['saida'] . ":00";
											}
											?></td>
								<td><?php if ($dados['data_saida'] == NULL) {
												echo "-";
											} else {
												echo $dados['data_saida'];
											}
											?></td>
								<td><?php

											if ($dados['saida'] == NULL) {
												echo "-";
											} else {

												echo $dados['hora_total'] . ":00";
											} ?></td>
								<td><?php
											if ($dados['saida'] == NULL) {
												echo "-";
											} else {



												echo "R$" . $dados['preco_total'];
											}
											?>
								</td>

								<?php if ($dados['saida'] == NULL) { ?>
									<td><a href="saida.php?id=<?php echo $dados['id']; ?>" class="btn-floating blue"><i class="material-icons">exit_to_app</i></a></td>
								<?php   } else { ?>
									<td>
										<!--<a href="" class="btn-floating orange"><i class="material-icons grey" disabled>exit_to_app</i></a>--><?php echo "-"; ?></td>

								<?php	}
										?>



								<?php if ($dados['saida'] == NULL) { ?>
									<td><a href="pdf_entrada.php?id=<?php echo $dados['id']; ?>" target="_blank" class="btn-floating blue"><i class="material-icons">local_printshop</i></a></td>
								<?php   } else { ?>
									<td><a href="gerarpdf.php?id=<?php echo $dados['id']; ?>" target="_blank" class="btn-floating black"><i class="material-icons black">local_printshop</i></a></td>

								<?php	}
										?>





								<?php if ($dadoss['admin'] == 0) { ?>
									<td><a href="" class="btn-floating orange" disabled><i class="material-icons">edit</i></a></td>
								<?php } else { ?>

									<td><a href="editar.php?id=<?php echo $dados['id']; ?>" class="btn-floating orange"><i class="material-icons">edit</i></a></td>

								<?php } ?>

								<?php if ($dadoss['admin'] == 0) { ?>
									<td><a href="" class="btn-floating red modal-trigger" disabled><i class="material-icons">delete</i></a></td>
								<?php } else { ?>

									<td><a href="#modal<?php echo $dados['id']; ?>" class="btn-floating red modal-trigger"><i class="material-icons">delete</i></a></td>
								<?php } ?>
								<!-- Modal Structure -->
								<?php if ($dadoss['admin'] == 1) : ?>
									<div id="modal<?php echo $dados['id']; ?>" class="modal">
										<div class="modal-content">
											<h4>Opa!</h4>
											<p>Tem certeza que deseja excluir esse cliente?</p>
										</div>
										<div class="modal-footer">

											<form action="php_action/delete.php" method="POST">
												<input type="hidden" name="id" value="<?php echo $dados['id']; ?>">
												<button type="submit" name="btn-deletar" class="btn red">Sim, quero deletar</button>

												<a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Cancelar</a>

											</form>

										</div>
									</div>
								<?php endif; ?>


							</tr>
						<?php
							endwhile;
						else : ?>

						<tr>
							<td>-</td>
							<td>-</td>
							<td>-</td>
							<td>-</td>
							<td>-</td>
							<td>-</td>
							<td>-</td>
							<td>-</td>
							<td>-</td>
						</tr>

					<?php
					endif;

					$result_pg = "SELECT COUNT(id) AS num_result FROM clientes";
					$resultado_pg = mysqli_query($connect, $result_pg);
					$row_pg = mysqli_fetch_assoc($resultado_pg);
					//echo $row_pg['num_result'];
					//Quantidade de paginas
					$quantidade_pg = ceil($row_pg['num_result'] / $qnt_result_pg);

					//Limitar os links
					$max_links = 2;



					for ($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++) {
						if ($pag_ant >= 1) {
							echo "<a href='http://localhost/25-sistemadelogin/28-crud/?pagina=$pag_ant' name='abacaxi' class='btn'>$pag_ant</a> ";
						}
					}

					echo "<div class='btn deep-orange ' name='abacaxi' disabled>$pagina</div> ";

					for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++) {
						if ($pag_dep <= $quantidade_pg) {
							echo "<a href='http://localhost/25-sistemadelogin/28-crud/?pagina=$pag_dep' name='abacaxi' class='btn'>$pag_dep</a> ";
						}
					}
					//	echo $_SESSION['mensagem'];


					?>

				</tbody>
			</table>
		</div>
	</div>
	<br>

	<a href="adicionar.php" class="btn">Adicionar Cliente</a><br><br>
</div>

<footer class="page-footer blue darken-3" style="position:absolute; bottom:0px; width:100%;">

	<div class="container center-align">
		&copy; Contato (99) 99999-9999 - controlveiculos@gmail.com - © 2019 Copyright
	</div>

</footer>
<?php


// Footer
include_once 'includes/footer.php';

?>
<script type="text/javascript" src="./jquery.min.js"></script>
<script type="text/javascript" src="personalizado.js"></script>