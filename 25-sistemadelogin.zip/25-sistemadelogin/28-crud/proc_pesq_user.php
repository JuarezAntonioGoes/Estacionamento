<?php
//Incluir a conexão com banco de dados
include_once 'php_action/db_connect.php';

include_once 'includes/header.php';
// Select
include_once 'includes/verificacao_login.php';

$id_adm = mysqli_escape_string($connect, $_SESSION['id_usuario']);

$res_adm = "SELECT * FROM usuarios WHERE id = '$id_adm'";
$resultado = mysqli_query($connect, $res_adm);
$dadoss = mysqli_fetch_array($resultado);

$usuarios = filter_input(INPUT_POST, 'palavra', FILTER_SANITIZE_STRING);

//Pesquisar no banco de dados nome do usuario referente a palavra digitada
$result_user = "SELECT * FROM clientes  WHERE placa LIKE '%$usuarios%' order by id DESC LIMIT 4";
$resultado_user = mysqli_query($connect, $result_user);


if (($resultado_user) and ($resultado_user->num_rows != 0)) {
	while ($row_user = mysqli_fetch_assoc($resultado_user)) {
		?>

		<table class="striped">
			<thead>
				<tr>
					<th>Placa:</th>
					<th>Hora de entrada:</th>
					<th>Data de entrada:</th>
					<th>Hora de saída:</th>
					<th>Data de saída:</th>
					<th>Horas utilizadas:</th>
					<th>Valor a pagar:</th>
				</tr>
			</thead>

			<tbody>
				<tr>

					<td><?php echo $row_user['placa']; ?></td>
					<td><?php echo $row_user['entrada']; ?></td>
					<td><?php echo $row_user['data_entrada']; ?></td>
					<td><?php if ($row_user['saida'] == NULL) {
									echo "-";
								} else {
									echo $row_user['saida'];
								}
								?></td>
					<td><?php if ($row_user['saida'] == NULL) {
									echo "-";
								} else {
									echo $row_user['data_saida'];
								}
								?></td>
					<td><?php

								if ($row_user['saida'] == NULL) {
									echo "-";
								} else {

									echo $row_user['hora_total'].":00";
								}
								?></td>
								<td><?php
										if ($row_user['saida'] == NULL) {
											echo "-";
										} else {



											echo "R$" . $row_user['preco_total'];
										}
										?>
							</td>
					<td><?php if ($row_user['saida'] == NULL) { ?>
					<td><a href="saida.php?id=<?php echo $row_user['id']; ?>" class="btn-floating blue"><i class="material-icons">exit_to_app</i></a></td>
				<?php   } else { ?>
					<td>
						<!--<a href="" class="btn-floating orange"><i class="material-icons grey" disabled>exit_to_app</i></a>--><?php echo "-"; ?></td>

				<?php	}
						?>



				<?php if ($row_user['saida'] == NULL) { ?>
					<td><a href="pdf_entrada.php?id=<?php echo $row_user['id']; ?>" target="_blank" class="btn-floating blue"><i class="material-icons">local_printshop</i></a></td>
				<?php   } else { ?>
					<td><a href="gerarpdf.php?id=<?php echo $row_user['id']; ?>" target="_blank" class="btn-floating black"><i class="material-icons black">local_printshop</i></a></td>

				<?php	}
						?>
				<?php if ($dadoss['admin'] == 0) { ?>
								<td><a href="" class="btn-floating orange" disabled><i class="material-icons">edit</i></a></td>
							<?php } else { ?>

								<td><a href="editar.php?id=<?php echo $row_user['id']; ?>" class="btn-floating orange"><i class="material-icons">edit</i></a></td>

							<?php } ?>

							<?php if ($dadoss['admin'] == 0) { ?>
								<td><a href="" class="btn-floating red modal-trigger" disabled><i class="material-icons">delete</i></a></td>
							<?php } else { ?>

								<td><a href="#modal<?php echo $row_user['id']; ?>" class="btn-floating red modal-trigger"><i class="material-icons">delete</i></a></td>
							<?php } ?>


		<?php
			}
		} else {
			echo "Nenhum usuário encontrado ...";
		}
