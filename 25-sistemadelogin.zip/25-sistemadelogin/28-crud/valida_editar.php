<script>
function validaaa() {
    if (document.form.placa.value == "") {
        M.toast({ html: 'Por favor, preencha o campo "Placa"' });
        document.form.placa.focus();
        return false;
    }
    if (document.form.placa.value.length < 8) {
        M.toast({ html: ' Placa inválida' });
        document.form.placa.focus();
        return false;
    }


    if (document.form.entrada.value == "") {
        M.toast({ html: 'Por favor, preencha o campo "Hora de entrada"' });
        document.form.entrada.focus();
        return false;
    }

    if (document.form.entrada.value.length < 5) {
        M.toast({ html: 'Hora de entrada inválida' });
        document.form.entrada.focus();
        return false;
    }

    if (document.form.data_entrada.value == "") {
        M.toast({ html: 'Por favor, preencha o campo "Data de entrada"' });
        document.form.data_entrada.focus();
        return false;
    }

    if (document.form.data_entrada.value.length < 10) {
        M.toast({ html: "Data de entrada inválida" });
        document.form.data_entrada.focus();
        return false;
    }
}
    </script>
